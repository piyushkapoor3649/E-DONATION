
<html>
    <head>
    <style>
ul.uppernavbar{
  list-style-type: none;
  margin: 0;
  padding: 0;
    width:100%;
  overflow: hidden;
  background-color: cadetblue;
    position: sticky;
    
}

li {
  float: left;
}

li a{
  display: block;
  color: white;
  text-align: center;
  padding: 5px 16px;
  text-decoration: none;
}

li a.hoveryes:hover {
  background-color: aliceblue;
    color: black;
    text-decoration: none;
}
        
.leftcontentupper{
            float: left;
            font-size: 45px;
}
        
.rightcontentupper{
    float:right;
    margin-top: 14px;
    font-size: 25px;
    margin-right: 10px;


}
    </style
    </head>
        
<body>

<ul class="uppernavbar">
        <div class="leftcontentupper">
  <li><a  style="text-decoration: none; color:white;">Admin Panel</a></li>
        </div>
        
        <div class="rightcontentupper">
        <li><a href="usersetting.php" class="hoveryes">Admin Profile</a></li>
        <li><a href="logout.php" class="hoveryes">Logout</a></li>
        </div>
</ul>

</body>
</html>