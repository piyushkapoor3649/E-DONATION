<!DOCTYPE html>
<html>
<head>
<style>
body {
  margin: 0;
}

ul.sidenav {
  list-style-type: none;
  margin: 0;
  padding-top: 100px;
  padding-left: 14px;
  padding-right: 14px;
  width: 260px;
  background-color:#333;
  position:absolute;
  height: 100%;
  overflow: auto;
  height: 1320px;
}

li a.sidenav{
  display: block;
  color: white;
  padding: 14px 60px;
  text-decoration: none;
}

li a.sidenav:hover {
  background-color: cadetblue;
  color: white;
 
    
}
      
    
    
    
</style>
</head>
<body>

<ul class="sidenav">
  <li><a href="home.php" class="sidenav">New Donations</a></li>
  <li><a href="reqconfirm.php" class="sidenav">Confirmed Donations</a></li>

</ul>



</body>
</html>