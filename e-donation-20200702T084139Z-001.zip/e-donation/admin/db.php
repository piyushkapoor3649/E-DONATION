<?php
$con = mysqli_connect("localhost","root","","final") or die(mysql_error());
?>